-- Database: annual_dashboard_db
CREATE DATABASE IF NOT EXISTS annual_dashboard_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE annual_dashboard_db;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- Sample admin user (email: admin@example.com | password: admin123)
INSERT INTO users (fullname, email, password) VALUES
('Admin User', 'admin@example.com', '$2y$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36kU6Y5rZ1bVdU3aUw5Eue2');
