<?php
// Placeholder page for: Course & Department Management
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Course & Department Management</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand">Institute</div>
    <nav>
      <!-- Sidebar links -->
      <?php foreach (["subject.php","teacher.php","student.php","course.php","feedback.php","fees.php","result.php","annual.php","events.php","summary.php","backup.php"] as $l): ?>
        <a class="nav-link" href="<?=htmlspecialchars($l)?>"><?=htmlspecialchars($l)?></a>
      <?php endforeach; ?>
    </nav>
  </aside>
  <main class="content">
    <header><h1>Course & Department Management</h1><a class="btn-logout" href="logout.php">Logout</a></header>
    <section class="card">
      <p>This is a placeholder page for <strong>Course & Department Management</strong>. You can build the module here.</p>
    </section>
  </main>
</div>
</body>
</html>
