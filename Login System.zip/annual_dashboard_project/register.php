<?php
session_start();
require_once 'db.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    if (strlen($fullname) < 3) $errors[] = 'Full name should be at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $password2) $errors[] = 'Passwords do not match.';
    if (empty($errors)) {
        $stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) { $errors[] = 'Email already registered.'; }
        $stmt->close();
    }
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $mysqli->prepare('INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $fullname, $email, $hash);
        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['user_name'] = $fullname;
            header('Location: dashboard.php');
            exit;
        } else { $errors[] = 'Registration failed, please try again.'; }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Register - Institute Portal</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body class="bg">
  <div class="overlay"></div>
  <div class="card">
    <h2>Create account</h2>
    <?php if (!empty($errors)): ?>
      <div class="alert"><ul><?php foreach ($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <form method="post" action="">
      <label>Full name</label>
      <input type="text" name="fullname" required value="<?=htmlspecialchars($fullname ?? '')?>">
      <label>Email</label>
      <input type="email" name="email" required value="<?=htmlspecialchars($email ?? '')?>">
      <label>Password</label>
      <input type="password" name="password" required>
      <label>Confirm Password</label>
      <input type="password" name="password2" required>
      <button type="submit">Register</button>
    </form>
    <div class="foot">Already have an account? <a href="index.php">Login</a></div>
  </div>
</body>
</html>
