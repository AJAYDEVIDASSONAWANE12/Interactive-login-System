<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
$user_name = $_SESSION['user_name'] ?? 'User';
$modules = [
  ['file'=>'subject.php','label'=>'Subject & Class Management','icon'=>'📘'],
  ['file'=>'teacher.php','label'=>'Teacher Registration & Timetable Generation','icon'=>'👨‍🏫'],
  ['file'=>'student.php','label'=>'Student Registration Module','icon'=>'🎓'],
  ['file'=>'course.php','label'=>'Course & Department Management','icon'=>'🏛'],
  ['file'=>'feedback.php','label'=>'Feedback System','icon'=>'💬'],
  ['file'=>'fees.php','label'=>'Student Fee & Account Management','icon'=>'💰'],
  ['file'=>'result.php','label'=>'Result & Performance Tracking','icon'=>'📈'],
  ['file'=>'annual.php','label'=>'Annual Report Generation','icon'=>'📊'],
  ['file'=>'events.php','label'=>'Events & Activities Section','icon'=>'🎉'],
  ['file'=>'summary.php','label'=>'Summary Dashboard','icon'=>'📋'],
  ['file'=>'backup.php','label'=>'Backup & Data Recovery','icon'=>'🗃'],
];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard - Institute Management</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand">Institute</div>
    <nav>
      <?php foreach($modules as $m): ?>
        <a class="nav-link" href="<?=htmlspecialchars($m['file'])?>"><?=htmlspecialchars($m['icon'])?> <?=htmlspecialchars($m['label'])?></a>
      <?php endforeach; ?>
    </nav>
  </aside>
  <main class="content">
    <header>
  <h1>Welcome to Annual Report for Institute</h1>
  <a class="btn-logout" href="logout.php">Logout</a>
</header>

    <section class="welcome">
      <h2>Dashboard Modules</h2>
      <p>Use the left menu to open module pages. Each module currently loads a placeholder blank page for future development.</p>
    </section>
  </main>
</div>
</body>
</html>
